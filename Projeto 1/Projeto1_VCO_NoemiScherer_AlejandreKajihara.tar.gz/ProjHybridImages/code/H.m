function res = H(u,v,s,d0)
res = e^-((D(u,v,s))^2/(2*d0^2));
endfunction
